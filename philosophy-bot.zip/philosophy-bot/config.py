# config.py

BOT_TOKEN = 'YOUR_BOT_TOKEN'  # Можно оставить как заглушку, если будем использовать переменные окружения
CHANNEL_ID = '@yourchannel'  # Или числовой ID (-100...)
GOOGLE_SHEET_URL = 'https://docs.google.com/spreadsheets/d/1aB8XbFgZ7wUvRqJ6Qj9nDpVWxNfKcA7sYrOzZ/edit?usp=sharing'